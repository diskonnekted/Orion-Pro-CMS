</div> <!-- End container -->

<footer class="bg-gray-800 text-white mt-12 py-8">
    <div class="container mx-auto px-4 text-center">
        <p>&copy; <?php echo date('Y'); ?> Orion CMS. Built with PHP Native & Tailwind.</p>
        <p class="text-gray-500 text-sm mt-2">Meniru struktur WordPress.</p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
